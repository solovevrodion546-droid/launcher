package com.voidlite.launcher.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.voidlite.launcher.LauncherApp
import com.voidlite.launcher.toImageBitmap
import kotlinx.coroutines.delay

/**
 * Иконка приложения с «пружинным» нажатием и каскадным появлением.
 * Долгое нажатие открывает системные настройки приложения.
 */
@Composable
fun AppIcon(
    app: LauncherApp,
    onClick: (Rect) -> Unit,
    modifier: Modifier = Modifier,
    showLabel: Boolean = true,
    entranceDelayMs: Int = 0,
) {
    val context = LocalContext.current

    var pressed by remember { mutableStateOf(false) }
    val pressScale by animateFloatAsState(
        targetValue = if (pressed) 0.82f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium,
        ),
        label = "pressScale",
    )

    val entrance = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (entranceDelayMs > 0) delay(entranceDelayMs.toLong())
        entrance.animateTo(
            1f,
            spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow),
        )
    }

    var bounds by remember { mutableStateOf<Rect?>(null) }
    val iconBitmap = remember(app.packageName) { app.icon.toImageBitmap() }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .onGloballyPositioned { bounds = it.boundsInRoot() }
            .graphicsLayer {
                val e = entrance.value
                alpha = e
                translationY = (1f - e) * 60f
                val s = pressScale * (0.5f + 0.5f * e)
                scaleX = s
                scaleY = s
            }
            .pointerInput(app.packageName) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { bounds?.let(onClick) },
                    onLongPress = {
                        runCatching {
                            context.startActivity(
                                Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.fromParts("package", app.packageName, null),
                                )
                            )
                        }
                    },
                )
            }
            .padding(horizontal = 4.dp, vertical = 6.dp),
    ) {
        Image(
            bitmap = iconBitmap,
            contentDescription = app.label,
            modifier = Modifier.size(56.dp),
        )
        if (showLabel) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = app.label,
                color = Color.White,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = TextStyle(shadow = Shadow(Color.Black, blurRadius = 10f)),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
