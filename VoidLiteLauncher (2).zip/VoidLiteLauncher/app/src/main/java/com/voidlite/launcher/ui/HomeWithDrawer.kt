package com.voidlite.launcher.ui

import android.app.ActivityOptions
import android.content.Context
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.voidlite.launcher.LauncherApp
import kotlinx.coroutines.launch

private const val COLUMNS = 4
private const val ROWS = 5
private const val PAGE_CAPACITY = COLUMNS * ROWS
private const val DOCK_SIZE = 5

/** Запуск приложения с анимацией «раскрытия из иконки». */
fun launchApp(context: Context, rootView: View, app: LauncherApp, bounds: Rect?) {
    val intent = context.packageManager.getLaunchIntentForPackage(app.packageName) ?: return
    rootView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    val options = if (bounds != null) {
        @Suppress("DEPRECATION")
        ActivityOptions.makeScaleUpAnimation(
            rootView,
            bounds.left.toInt(),
            bounds.top.toInt(),
            bounds.width.toInt().coerceAtLeast(1),
            bounds.height.toInt().coerceAtLeast(1),
        )
    } else {
        ActivityOptions.makeBasic()
    }
    runCatching { context.startActivity(intent, options.toBundle()) }
        .onFailure { context.startActivity(intent) }
}

@Composable
fun HomeWithDrawer(apps: List<LauncherApp>) {
    val context = LocalContext.current
    val rootView = LocalView.current
    val scope = rememberCoroutineScope()

    val dockApps = remember(apps) { apps.take(DOCK_SIZE) }
    val homeApps = remember(apps) { apps.drop(DOCK_SIZE) }
    val pages = remember(homeApps) {
        homeApps.chunked(PAGE_CAPACITY).ifEmpty { listOf(emptyList()) }
    }

    // 1f = меню приложений закрыто, 0f = полностью открыто
    val drawerOffset = remember { Animatable(1f) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val screenHeightPx = constraints.maxHeight.toFloat()
        val openFraction = 1f - drawerOffset.value

        fun animateDrawerTo(target: Float, velocityPxPerSec: Float = 0f) {
            scope.launch {
                drawerOffset.animateTo(
                    targetValue = target,
                    animationSpec = spring(
                        dampingRatio = 0.92f,
                        stiffness = Spring.StiffnessMediumLow,
                    ),
                    initialVelocity = velocityPxPerSec / screenHeightPx,
                )
            }
        }

        fun settleDrawer(velocityPxPerSec: Float) {
            val vOffset = velocityPxPerSec / screenHeightPx
            val target = when {
                vOffset < -1.2f -> 0f // быстрый свайп вверх — открыть
                vOffset > 1.2f -> 1f  // быстрый свайп вниз — закрыть
                drawerOffset.value < 0.5f -> 0f
                else -> 1f
            }
            animateDrawerTo(target, velocityPxPerSec)
        }

        // ---------------- Рабочий стол ----------------
        val homeModifier = Modifier
            .fillMaxSize()
            .graphicsLayer {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val r = openFraction * 30f
                    renderEffect = if (r > 0.5f) {
                        RenderEffect
                            .createBlurEffect(r, r, Shader.TileMode.CLAMP)
                            .asComposeRenderEffect()
                    } else {
                        null
                    }
                }
                clip = true
                alpha = 1f - openFraction * 0.35f
            }
            .pointerInput(screenHeightPx) {
                val tracker = VelocityTracker()
                detectVerticalDragGestures(
                    onDragStart = { tracker.resetTracking() },
                    onVerticalDrag = { change, dragAmount ->
                        tracker.addPosition(change.uptimeMillis, change.position)
                        scope.launch {
                            drawerOffset.snapTo(
                                (drawerOffset.value + dragAmount / screenHeightPx)
                                    .coerceIn(0f, 1f)
                            )
                        }
                    },
                    onDragEnd = { settleDrawer(tracker.calculateVelocity().y) },
                    onDragCancel = { settleDrawer(0f) },
                )
            }

        Column(homeModifier.safeDrawingPadding()) {
            val pagerState = rememberPagerState(pageCount = { pages.size })

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) { page ->
                val pageApps = pages[page]
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(start = 12.dp, end = 12.dp, top = 24.dp)
                ) {
                    for (row in 0 until ROWS) {
                        Row(
                            Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            for (col in 0 until COLUMNS) {
                                val index = row * COLUMNS + col
                                Box(
                                    Modifier.weight(1f),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    pageApps.getOrNull(index)?.let { app ->
                                        AppIcon(
                                            app = app,
                                            onClick = { bounds ->
                                                launchApp(context, rootView, app, bounds)
                                            },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Точки-индикаторы страниц
            if (pages.size > 1) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    repeat(pages.size) { i ->
                        val selected = pagerState.currentPage == i
                        Box(
                            Modifier
                                .padding(3.dp)
                                .size(if (selected) 7.dp else 5.dp)
                                .clip(CircleShape)
                                .background(
                                    if (selected) Color.White
                                    else Color.White.copy(alpha = 0.4f)
                                )
                        )
                    }
                }
            }

            // ---------------- Док ----------------
            Surface(
                color = Color.Black.copy(alpha = 0.30f),
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier
                    .padding(start = 16.dp, end = 16.dp, bottom = 10.dp)
                    .fillMaxWidth(),
            ) {
                Row(
                    Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    dockApps.forEach { app ->
                        Box(
                            Modifier.weight(1f),
                            contentAlignment = Alignment.Center,
                        ) {
                            AppIcon(
                                app = app,
                                showLabel = false,
                                onClick = { bounds ->
                                    launchApp(context, rootView, app, bounds)
                                },
                            )
                        }
                    }
                }
            }
        }

        // ---------------- Меню приложений ----------------
        if (drawerOffset.value < 0.999f) {
            AppDrawer(
                apps = apps,
                onClose = { animateDrawerTo(1f) },
                onLaunch = { app, bounds -> launchApp(context, rootView, app, bounds) },
                onDrag = { dragAmount ->
                    scope.launch {
                        drawerOffset.snapTo(
                            (drawerOffset.value + dragAmount / screenHeightPx)
                                .coerceIn(0f, 1f)
                        )
                    }
                },
                onDragEnd = { velocity -> settleDrawer(velocity) },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { translationY = drawerOffset.value * screenHeightPx },
            )
        }
    }
}
