# Void Lite Launcher

Минималистичный Android-лаунчер в духе VoidLauncher: обои на весь экран,
«пружинные» иконки, меню приложений по свайпу вверх с размытием фона и
запуск приложений с анимацией «из иконки».

## Получить готовый APK без компьютера — пошагово

Ничего устанавливать не нужно, всё делается в браузере телефона (~10 минут).

1. Скачайте `VoidLiteLauncher.zip` на телефон. **Распаковывать не нужно.**
2. Откройте `github.com` в Chrome. В меню браузера (⋮) включите **«Версия для ПК»**.
3. Создайте аккаунт, если его нет. Нажмите **+** → **New repository** →
   введите любое имя (например `launcher`) → **Create repository**.
4. На странице репозитория нажмите ссылку **«uploading an existing file»**
   (или **Add file → Upload files**). Выберите `VoidLiteLauncher.zip` целиком.
   Нажмите **Commit changes**.
5. Нажмите **Add file → Create new file**. В поле имени файла введите точно:

   ```
   .github/workflows/build.yml
   ```

   (слеши сами превратятся в папки). В большое поле вставьте весь текст из
   файла `build.yml` ниже, затем **Commit changes**.
6. Откройте вкладку **Actions** — сборка запустится автоматически.
   Если не началась: **Actions → Build APK → Run workflow**.
   Дождитесь зелёной галочки (~5 минут).
7. Откройте завершённую сборку → внизу **Artifacts → void-lite-apk** → скачайте.
   Внутри скачанного zip будет готовый **`app-debug.apk`**.
8. Откройте `app-debug.apk` на телефоне, разрешите установку из неизвестных
   источников → **Установить**.

### Текст для файла build.yml (шаг 5)

```yaml
name: Build APK

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Распаковать проект
        run: unzip -o VoidLiteLauncher.zip -d unpacked

      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17

      - name: Установить Gradle
        run: |
          wget -q https://services.gradle.org/distributions/gradle-8.9-bin.zip -O /tmp/gradle.zip
          unzip -q /tmp/gradle.zip -d /opt
          echo "/opt/gradle-8.9/bin" >> "$GITHUB_PATH"

      - name: Собрать APK
        working-directory: unpacked/VoidLiteLauncher
        run: gradle assembleDebug --no-daemon --stacktrace

      - name: Загрузить готовый APK
        uses: actions/upload-artifact@v4
        with:
          name: void-lite-apk
          path: unpacked/VoidLiteLauncher/app/build/outputs/apk/debug/app-debug.apk
```

## Сделать лаунчером по умолчанию (Xiaomi 13 Ultra, HyperOS)

**Настройки → Приложения → Все приложения → меню ⋮ → Приложения по умолчанию → Рабочий стол → Void Lite**

Либо нажмите кнопку «Домой» и выберите Void Lite → «Всегда».

Особенности HyperOS: при стороннем лаунчере жестовая навигация может быть
недоступна — тогда включите кнопки в *Настройки → Рабочий стол → Системная
навигация*. Анимация закрытия приложений жестом «домой» остаётся системной —
это ограничение Android для всех сторонних лаунчеров без root.

## Сборка на компьютере (альтернатива)

Откройте папку проекта в Android Studio → **Build → Build APK(s)**.
Готовый файл: `app/build/outputs/apk/debug/app-debug.apk`.

## Структура проекта

- `ui/HomeWithDrawer.kt` — рабочий стол, док, жест свайпа вверх, размытие фона
- `ui/AppDrawer.kt` — меню приложений, поиск, ручка для закрытия
- `ui/AppIcon.kt` — анимации иконок (пружина при нажатии, каскадное появление)
- `LauncherApps.kt` — загрузка списка установленных приложений
- `ui/LauncherRoot.kt` — фон (обои) и общая тема
